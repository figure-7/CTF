# Crypt0r part 1

Our IDS detected an abnormal behavior from one of our user. We extracted this pcap, could you have a look at it? 

<a href="http://crypt0r.challenge-by.ovh/ids_alert_24032018.pcap">http://crypt0r.challenge-by.ovh/ids_alert_24032018.pcap</a>

